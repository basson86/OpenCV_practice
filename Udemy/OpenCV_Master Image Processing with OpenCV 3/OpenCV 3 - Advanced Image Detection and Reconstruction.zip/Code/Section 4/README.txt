This directory contains material supporting Section 4 of the Course:  OpenCV 3 � Advanced Image Detection and Reconstruction. 
by Robert Laganiere, Packt Publishing, 2017.

Files: 
        recognizeFace.cpp
correspond to Video:
Recognizing faces using nearest neighbors of local binary patterns

Files: 
        detectObjects.cpp
correspond to Video:
Finding objects and faces with a cascade of Haar features

Files: 
	trainSVM.cpp
correspond to Video:
Detecting objects and peoples with Support Vector Machines and histograms of oriented gradients 

You need the images:
girl.jpg
face0_1.png
face0_2.png
face1_1.png
face1_2.png
person.jpg
and the directory:
stopSamples/