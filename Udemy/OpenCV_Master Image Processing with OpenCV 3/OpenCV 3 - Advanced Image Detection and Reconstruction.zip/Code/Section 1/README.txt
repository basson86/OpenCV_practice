This directory contains material supporting Section 1 of the course:  
OpenCV 3 � Advanced Image Detection and Reconstruction. 
by Robert Laganiere, Packt Publishing, 2017.

Files:
	harrisDetector.h
	interestPoints.cpp
correspond to video:
Detecting Corners in images
Detecting features very fast
Detecting Scale-Invariant Features
Detecting fast features at multiple scales

You need the images:
church01.jpg
church02.jpg
church03.jpg
