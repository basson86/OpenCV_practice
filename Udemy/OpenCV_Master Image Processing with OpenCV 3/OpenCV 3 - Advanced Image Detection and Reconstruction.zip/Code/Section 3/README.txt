This directory contains material supporting Section 3 of the Course:  OpenCV 3 � Advanced Image Detection and Reconstruction. 
by Robert Laganiere, Packt Publishing, 2017.

File:
	estimateF.cpp
correspond to Video:
Computing the Fundamental Matrix of an Image Pair
Files:
	matcher.h
	robustmatching.cpp
correspond to Video:
Matching Images using Random Sample Consensus
File:
	estimateH.cpp
correspond to Video:
Computing a homography between two images
Files:
	matchingTarget.cpp
        targetMatcher.h
correspond to Video:
Computing a homography between two images

You need the images:

church01.jpg
church02.jpg
church03.jpg
parliament1.jpg
parliament2.jpg
parliament3.jpg
cookbook1.bmp
objects.jpg


