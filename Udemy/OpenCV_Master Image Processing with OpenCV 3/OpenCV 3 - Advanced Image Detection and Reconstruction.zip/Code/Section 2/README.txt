This directory contains material supporting Section 2 of the Course:  OpenCV 3 � Advanced Image Detection and Reconstruction. 
by Robert Laganiere, Packt Publishing, 2017.

File:
	patches.cpp
correspond to Video:
Matching local templates

File:
	matcher.cpp
correspond to Video:
Describing and matching local intensity patterns

File:
	binaryDescriptors.cpp
correspond to Video:
Describing keypoints with binary features

You need the images:
church01.jpg
church02.jpg
church03.jpg
