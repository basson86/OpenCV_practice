This directory contains material supporting section 2 of the Course:
OpenCV 3 – Getting started with Image processing
by Robert Laganiere, Packt Publishing, 2017.

File:
	saltImage.cpp
correspond to Video:
Accessing the pixel values

File:
	colorReduce.cpp
correspond to Videos:
Scanning an image with pointers
Scanning an image with iterators
Writing efficient image scanning loops

File:
	contrast.cpp
correspond to Video:
Scanning an image with neighbour access

File:
	addImages.cpp
correspond to Video:
Performing simple image arithmetic

File:
	remapping.cpp
correspond to Video:
Remapping an image

You need the images:
boldt.jpg
rain.jpg
