This directory contains material supporting section 3 of the course:
OpenCV 3 – Getting started with Image processing
by Robert Laganiere, Packt Publishing, 2017.

Files:
	colordetector.h
	colordetector.cpp
	colorDetection.cpp
corresponds to Video:
Using the Strategy Pattern in Algorithm Design

File:
	extractObject.cpp
correspond to Video:
Segmenting an image with the GrabCut algorithm

File:
	huesaturation.cpp
correspond to Video:
Representing colors with hue, saturation and brightness

You need the images:
boldt.jpg
girl.jpg
