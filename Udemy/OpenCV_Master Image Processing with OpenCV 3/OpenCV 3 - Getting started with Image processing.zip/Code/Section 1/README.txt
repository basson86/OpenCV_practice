This directory contains material supporting Section 1 of the Course:
OpenCV 3 – Getting started with Image processing
by Robert Laganiere, Packt Publishing, 2017.


File:
	loadDisplaySave.cpp
corresponds to Video:
Loading, displaying and saving images

File:
	mat.cpp
corresponds to Video:
Exploring the cv::Mat data structure

File:
	logo.cpp
corresponds to Video:
Defining region of interest
